/** IGNIS Tailwind preset — import tokens.css first, then: presets: [require('./brand/tokens/tailwind.preset.js')] */
module.exports = {
  theme: {
    extend: {
      colors: {
        ignis: {
          'brand-yellow': 'var(--ignis-brand-yellow)',
          'on-brand': 'var(--ignis-on-brand)',
          'brand-text': 'var(--ignis-brand-text)',
          'surface-0': 'var(--ignis-surface-0)',
          'surface-1': 'var(--ignis-surface-1)',
          'line': 'var(--ignis-line)',
          'ink': 'var(--ignis-ink)',
          'ink-muted': 'var(--ignis-ink-muted)',
        },
      },
    },
  },
};
